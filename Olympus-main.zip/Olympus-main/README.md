# Olympus
Olympus: programa de assinatura para academias.

Plans:

Zeus: R$150.00
20 academias
Todos os dias
+5 academias de crossfit
1 aulas de artes marciais por semana
+5 academias de artes marciais
sessões com personal 2/semana
